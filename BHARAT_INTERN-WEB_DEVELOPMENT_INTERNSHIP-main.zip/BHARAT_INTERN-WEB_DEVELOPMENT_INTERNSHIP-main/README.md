# BHARAT-INTERN INTERNSHIP PROGRAM
Projects on Web Development Internship

Task 1 - Portfolio Website : A portfolio website made up of HTML,CSS telling about you and your accomplishments.

Task 2 - Temperature Converter : Create a simple website using HTML,CSS,JAVASCRIPT to convert temperature form Celsius to Fahrenheit and etc.

Task 3 -  Homepage of Netflix : A simple website having similar homepage that of Netflix using using HTML and CSS.



